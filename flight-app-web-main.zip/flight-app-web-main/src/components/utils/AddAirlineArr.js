export const sourceArr = ["mumbai", "pune", "delhi", "Bangalore","chandigarh"];

export const destArr = ["pune", "delhi", "Bangalore","chandigarh","mumbai"];

export const mealType = ["Veg", "Non-Veg"];

export const tripType = ["One Way", "Round Trip"];

export const seatTypeArr = ["Economy","business"]



