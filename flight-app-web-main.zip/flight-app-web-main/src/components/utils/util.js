export const dayMonth = (d) => {

    return d < 10 ? "0"+d : d;
}